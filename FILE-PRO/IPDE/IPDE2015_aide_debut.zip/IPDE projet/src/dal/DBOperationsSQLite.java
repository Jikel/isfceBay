package dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;

import model.Utilisateur;

public class DBOperationsSQLite implements DBOperations {

	private static String dbUrl="jdbc:sqlite:C:\\sqlite_db\\dbchris.sqlite";
	
	public DBOperationsSQLite() {
		try {
			Class.forName("org.sqlite.JDBC");
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}

	public LinkedList<Utilisateur> getUtilisateurs() {

		LinkedList<Utilisateur> utilisateurs = new LinkedList<Utilisateur>();
		Connection c = null;
		Statement stmt = null;

		try {
			c = DriverManager
					.getConnection(dbUrl);
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM utilisateur;");

			while (rs.next()) {
				int id = rs.getInt("id");
				String nom = rs.getString("nom");
				String mail = rs.getString("mail");
				String password = rs.getString("password");
				/*
				System.out.println("ID = " + id);
				System.out.println("NOM = " + nom);
				System.out.println("MAIL = " + mail);
				System.out.println("PASSWORD = " + password);
				*/
				Utilisateur utilisateur = new Utilisateur();
				utilisateur.setDbId(id);
				utilisateur.setNom(nom);
				utilisateur.setMail(mail);
				utilisateur.setPassword(password);
				utilisateurs.add(utilisateur);
			}
			
			rs.close();
			stmt.close();
			c.close();
			return (utilisateurs);
	
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			return null;
		}

	}

	public boolean createUtilisateur(Utilisateur newUtilisateur) {
		return false; // A IMPLEMENTER
	}

	public Utilisateur getUtilisateur(String log, String pwd) {
		Connection c = null;
		PreparedStatement stmt = null;

		try {
			Utilisateur utilisateur = null;
			c = DriverManager
					.getConnection(dbUrl);
			c.setAutoCommit(false);
			stmt = c.prepareStatement("SELECT * FROM utilisateur WHERE mail=? AND password=?");
			stmt.setString(1, log);
			stmt.setString(2, pwd);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				int id = rs.getInt("id");
				String nom = rs.getString("nom");
				String mail = rs.getString("mail");
				String password = rs.getString("password");
				utilisateur = new Utilisateur();
				utilisateur.setDbId(id);
				utilisateur.setNom(nom);
				utilisateur.setMail(mail);
				utilisateur.setPassword(password);
			}
			return utilisateur;

		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			return null;
		}
	}

}
