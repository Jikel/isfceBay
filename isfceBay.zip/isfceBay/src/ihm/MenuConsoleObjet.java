package ihm;

import java.util.LinkedList;
import java.util.Scanner;

import uc.GestionObjets;


/**
 * Cette classe sert à interagir avec l'utilisateur. 
 * Elle affiche le menu et toutes les informations que verra l'utilisateur.
 * C'est grâce à elle que l'utilisateur pourra encoder des informations.
 */
public class MenuConsoleObjet {
	
	// objet scanner qui permettra de lire ce que l'utilisateur tape au clavier
	static private Scanner scanner = new Scanner(System.in);
	
	// objet représentant les fonctionnalités de la gestion d'objets
	//private GestionObjets = new 

	public static void main(String[] args) {

	}

}
